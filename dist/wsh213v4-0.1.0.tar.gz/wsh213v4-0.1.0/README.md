### Taken from [the Waveshare manual](https://www.waveshare.com/wiki/2.13inch_e-Paper_HAT_Manual)

```bash
pip install git+https://github.com/azazelcodes/waveshare_two_thirteen.git
```
