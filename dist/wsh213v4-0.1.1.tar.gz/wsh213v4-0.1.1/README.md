### Taken from [the Waveshare manual](https://www.waveshare.com/wiki/2.13inch_e-Paper_HAT_Manual)

```bash
pip install wsh213v4
```
